package combates;


public class NoHayArchivoDeEntrada extends Exception {

	NoHayArchivoDeEntrada(String mensaje){
		super(mensaje);
	}
}
