package combates;


public class CompetidorCaracteristicaInvalidaException extends Exception {

	public CompetidorCaracteristicaInvalidaException(String msg) {
		super(msg);
	}
}
