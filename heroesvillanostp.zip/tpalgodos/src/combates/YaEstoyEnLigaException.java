package combates;


public class YaEstoyEnLigaException extends Exception {

	public YaEstoyEnLigaException(String msg) {
		super(msg);
	}
}
