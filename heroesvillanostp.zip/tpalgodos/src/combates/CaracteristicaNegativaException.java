package combates;


public class CaracteristicaNegativaException extends Exception {

	public CaracteristicaNegativaException(String msg) {
		super(msg);
	}
}
