package combates;


public enum Caracteristica {

	FUERZA,DESTREZA,VELOCIDAD,RESISTENCIA;
	
}
