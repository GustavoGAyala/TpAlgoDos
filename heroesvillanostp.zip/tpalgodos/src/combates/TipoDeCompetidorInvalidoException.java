package combates;


public class TipoDeCompetidorInvalidoException extends Exception {

	public TipoDeCompetidorInvalidoException (String msg) {
		super(msg);
	}
}
